/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ApiLayer;


import Model.Dictionary;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import jdk.nashorn.api.scripting.JSObject;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
/**
 *
 * @author namdy
 */
public class Oxford {
    
    public String URL_OXFORD = "https://od-api.oxforddictionaries.com/api/v1/inflections/en/";
    
    //this function check oxford dictionary and return isEnglish or not
    public boolean httpGet(String word) {

    List<Dictionary> dataFromService = new ArrayList<Dictionary>();
    try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
        HttpGet request = new HttpGet(URL_OXFORD + word);   
        request.addHeader("content-type", "application/json");
        request.addHeader("app_id", "dfe153cb");
        request.addHeader("app_key", "bc090ef59b37e377ca4615c135f5e09c");
        HttpResponse result = httpClient.execute(request);
        
        
        // in here checkng request code (HTTP request Code) if IsEnglish word the it's return 200 and whether not return 400
        if(result.getStatusLine().getStatusCode() == 200)
            return true;
        return false;

    } catch (IOException ex) {
        return false;
    }
    

   }
    
}
