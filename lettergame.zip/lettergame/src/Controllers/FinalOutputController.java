/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Service.errorHandling;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import lettergame.Constants;
import lettergame.ControlledScreen;
import lettergame.ScreensController;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class FinalOutputController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    Constants consData = new Constants();
    errorHandling Error = new errorHandling();

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnMenu;
    @FXML
    private Label labelMarks,statusLabel,winnerName;
    
    private String statusWOn = "Congratulation !! You won the Game";
    private String statusLoose = "Sorry !! You Loose the Game";
    
    private String WinnerName;
    private Integer playerFullMarks;
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void btnMainMenu_CLick() throws IOException {
        myController.setScreen(Constants.MENU_SCREEN);
    
    }
    
     @FXML
    private void Handle_close() throws IOException {
        Error.ExistFromGame();       
    }
    private String GetwinnerName(){
        
        //Need to get winner name .get MAX() value
        
        return "chathuranga";    
    }
    
    private void saveplayerscore(){
        // Need to save in db playerFullMarks , WinnerName
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        WinnerName = GetwinnerName();        
        labelMarks.setText(consData.InfoData.get("tempFullMark"));
        playerFullMarks = Integer.parseInt(consData.InfoData.get("tempFullMark"));
        saveplayerscore();
        
        // need to return boolean value Won or Lose and Winner Name
        
        winnerName.setText(WinnerName);
        statusLabel.setText("Congratulation !! You won the Game");
    }    
    
}
