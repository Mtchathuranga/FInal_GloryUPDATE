/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Service.errorHandling;
import java.io.IOException;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTreeTableColumn;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.util.Callback;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class LeaderBoardController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    errorHandling Error = new errorHandling();

    /**
     * Initializes the controller class.
     */
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
    
    @FXML
    private JFXTreeTableView<Person> table;
    
    ObservableList<Person> person = FXCollections.observableArrayList();
       
     @FXML
    private void handle_go_Back() throws IOException {
        myController.setScreen(Constants.MENU_SCREEN);
      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Error.ExistFromGame();
       
    }
       @FXML
    private void Handle_close() throws IOException {
       Error.ExistFromGame();       
    }
    
    public void showTableData(){
        JFXTreeTableColumn<Person,String> place = new JFXTreeTableColumn("Place");
	place.setPrefWidth(70);
	
	place.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>() {
	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<Person, String> param) {
                return param.getValue().getValue().place;
            }
        });
        
        JFXTreeTableColumn<Person,String> name = new JFXTreeTableColumn("Player Name");
	name.setPrefWidth(300);
        name.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>() {
	          
	@Override
        public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<Person, String> param) {
              return param.getValue().getValue().name;
        }
        });
                        
        JFXTreeTableColumn<Person,String> Score = new JFXTreeTableColumn("Score");
	Score.setPrefWidth(165);
	
	Score.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>() {
	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<Person, String> param) {
                return param.getValue().getValue().Score;
            }
        });
		person.add(new Person("1","Genius Coders","20"));
		person.add(new Person("2","Nilesh Kadam","20"));
		person.add(new Person("3","Shailesh Kadam","18"));
		person.add(new Person("4","Subscirbers","21"));
                person.add(new Person("5","Subscirbers","21"));
                person.add(new Person("6","Subscirbers","21"));
		
		final TreeItem<Person> root = new RecursiveTreeItem<Person>(person, RecursiveTreeObject::getChildren);
		table.getColumns().setAll(place,name,Score);
		table.setRoot(root);
		table.setShowRoot(false);    
    }
    
    private void addTableData(){
     /**
     * need to get played users score in ascending order then can view(score)
     * ORDER BY SCORE from Permanent table(name , score)
     * person.add(new Person("1","Genius Coders","20"));
     * 
     * 
     * 
     *      for(int i = 0; i< arr.size(); i++){                       
            obj1 = (JSONObject)arr.get(i);            
            person.add(new online(Integer.toString(i+1),obj1.get("userName").toString()));
        } 
     */
    
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addTableData();
        showTableData();
    }    
    
}

class Person extends RecursiveTreeObject<Person>{
		StringProperty name;
		StringProperty Score;
                StringProperty place;	
		
		public Person(String place,String name,String score)
		{
			this.name = new SimpleStringProperty(name);
			this.Score  = new SimpleStringProperty(score);
                        this.place  = new SimpleStringProperty(place);
			
			
		}
		
		
}
