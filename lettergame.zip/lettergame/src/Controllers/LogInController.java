/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
import Service.UserService;
import Service.errorHandling;
/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class LogInController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    UserService userServiceData= new UserService();
    Constants consData = new Constants();
    errorHandling Error = new errorHandling();
    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField text_UserName;
    @FXML
    private PasswordField text_UserPasword;
    
    private boolean logStatus ;
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
        @FXML
    private void handle_go_Back() throws IOException {        
        myController.setScreen(Constants.MENU_SCREEN);      
    }    
       @FXML
    private void Handle_Exist() throws IOException {
        Error.ExistFromGame();      
    }     
       @FXML
    private void Handle_close() throws IOException {        
        Error.ExistFromGame();       
    }
    
         @FXML
    private void Handle_sign_In() throws IOException {        
        if(this.text_UserName.getText() !=null && this.text_UserPasword.getText() != null ){
            logStatus = userServiceData.signin( this.text_UserName.getText(), this.text_UserPasword.getText());
            System.out.println(logStatus);
            if(!logStatus){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Log In Failed");
                alert.setHeaderText("Please Enter Corret Values.if not register,Please register ! ");
                alert.showAndWait(); 
                text_UserName.setText("");text_UserPasword.setText("");
            }else{
                consData.OnlinePlayerName = text_UserName.getText().toString();
                consData.addMap("LogInName", text_UserName.getText().toString());
                consData.addMap("tempRound","0");
                consData.addMap("tempMark","0");
                consData.addMap("tempFullMark","0");
                consData.addMap("NoOfPlayers","0");
                myController.loadScreen(Constants.OnlinePlayers_SCREEN, Constants.OnlinePlayers_SCREEN_FXML);
                myController.setScreen(Constants.OnlinePlayers_SCREEN);            
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Log In Failed");
            alert.setHeaderText("Please Enter values ! ");
            alert.showAndWait();        
        }
    }
          @FXML
    private void NavigateToRegister() throws IOException {        
        myController.setScreen(Constants.REGISTER_SCREEN);       
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        text_UserName.setText("");text_UserPasword.setText("");
    }
}
