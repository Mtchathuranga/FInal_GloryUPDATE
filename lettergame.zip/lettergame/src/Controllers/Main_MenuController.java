/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Service.errorHandling;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;

/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class Main_MenuController implements Initializable,ControlledScreen {
    
    ScreensController myController = new ScreensController();
    errorHandling Error = new errorHandling();
    /**
     * Initializes the controller class.
     */
     @FXML
    private void Handle_close() throws IOException {
        Error.ExistFromGame();
    }
    
        @FXML
    private void handle_option() throws IOException {      
       myController.setScreen(Constants.Option_SCREEN);
       
    }
    
          @FXML
    private void handle_HowtoPlay() throws IOException {
        myController.setScreen(Constants.HowToPlay_SCREEN); 
    }
    
          @FXML
    private void handle_PlayNow() throws IOException {      
       myController.setScreen(Constants.Login_SCREEN);      
       
    }
           @FXML
    private void handle_Quit() throws IOException {        
       Error.ExistFromGame();
    }
            @FXML
    private void handle_Board() throws IOException {
      myController.setScreen(Constants.Board_SCREEN);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
  
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
                
                
    }
    
}
