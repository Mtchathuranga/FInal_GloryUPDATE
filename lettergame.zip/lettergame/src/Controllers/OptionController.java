/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Service.errorHandling;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ToggleButton;
import lettergame.Constants;
import lettergame.ControlledScreen;
import lettergame.PropertyHandler;
import lettergame.ScreensController;


/**
 * FXML Controller class
 *
 * @author Mtchathuranga
 */
public class OptionController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();
    errorHandling Error = new errorHandling();

    /**
     * Initializes the controller class.
     */
    @FXML
    private ToggleButton  SoundsCheckBox;
    
   
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
     @FXML
    private void handle_go_Back() throws IOException {
        myController.setScreen(Constants.MENU_SCREEN);
      
    }
     @FXML
    private void Handle_save() throws IOException {
        System.out.println(SoundsCheckBox.isSelected());
        //Need to handle Music Enable and Disable
      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Error.ExistFromGame();
    }
       @FXML
    private void Handle_close() throws IOException {
        Error.ExistFromGame();    
    }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
