/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Service.errorHandling;
import java.io.IOException;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTreeTableColumn;

import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import java.util.Optional;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.util.Callback;
import lettergame.ScreensController;
import lettergame.ControlledScreen;
import lettergame.Constants;
/**
 * FXML Controller class
 *
 * @author tchathuranga
 */
public class ScoresFinalController implements Initializable,ControlledScreen {
    ScreensController myController = new ScreensController();    
    Constants consData = new Constants();
    errorHandling Error = new errorHandling();
    /**
     * Initializes the controller class.
     */
    

    
    @FXML
    private JFXTreeTableView<finalUserScores> table;
    ObservableList<finalUserScores> finalUserScores = FXCollections.observableArrayList();
    
    public void setScreenParent(ScreensController screenPage) {
		// TODO Auto-generated method stub
		myController = screenPage;
    }
    @FXML
    private void handle_go_Back() throws IOException {
        myController.setScreen(Constants.OutPut_SCREEN);
      
    }
    
       @FXML
    private void Handle_Exist() throws IOException {
        Error.ExistFromGame();
    }
    @FXML
    private void Handle_close() throws IOException {
       Error.ExistFromGame();
    }
    
    public void showTableData(){
        JFXTreeTableColumn<finalUserScores,String> place = new JFXTreeTableColumn("Place");
	place.setPrefWidth(70);	
	place.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<finalUserScores, String>, ObservableValue<String>>() {	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<finalUserScores, String> param) {
                return param.getValue().getValue().place;
            }
        });
        
        JFXTreeTableColumn<finalUserScores,String> name = new JFXTreeTableColumn("Player Name");
	name.setPrefWidth(300);
        name.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<finalUserScores, String>, ObservableValue<String>>() {	          
	@Override
        public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<finalUserScores, String> param) {
              return param.getValue().getValue().name;
        }
        });
                        
        JFXTreeTableColumn<finalUserScores,String> Score = new JFXTreeTableColumn("Score");
	Score.setPrefWidth(165);	
	Score.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<finalUserScores, String>, ObservableValue<String>>() {	          
	    @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<finalUserScores, String> param) {
                return param.getValue().getValue().Score;
            }
        });
                
		finalUserScores.add(new finalUserScores("1","Genius Coders","20"));
		finalUserScores.add(new finalUserScores("2","Nilesh Kadam","20"));
		finalUserScores.add(new finalUserScores("3","Shailesh Kadam","18"));
		finalUserScores.add(new finalUserScores("4","Subscirbers","21"));
                finalUserScores.add(new finalUserScores("5","Subscirbers","21"));
                finalUserScores.add(new finalUserScores("6","Subscirbers","21"));
		
		final TreeItem<finalUserScores> root = new RecursiveTreeItem<finalUserScores>(finalUserScores, RecursiveTreeObject::getChildren);
		table.getColumns().setAll(place,name,Score);
		table.setRoot(root);
		table.setShowRoot(false);
    
    }
    private void AddData(){
        
     /**
     * need to get played users score in ascending order then can view(score)
     * -----ORDER BY SCORE. From temp table(name,Score)----------
     * finalUserScores.add(new finalUserScores("4","Subscirbers","21"));
     * 
     * for(int i = 0; i< arr.size(); i++){                       
            obj1 = (JSONObject)arr.get(i);            
            person.add(new online(Integer.toString(i+1),obj1.get("userName").toString()));
        } 
     */
    
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        AddData();
        showTableData();
        
    } 
}

class finalUserScores extends RecursiveTreeObject<finalUserScores>{
		StringProperty name;
		StringProperty Score;
                StringProperty place;		
		public finalUserScores(String place,String name,String score)
		{
			this.name = new SimpleStringProperty(name);
			this.Score  = new SimpleStringProperty(score);
                        this.place  = new SimpleStringProperty(place);
		}
}
