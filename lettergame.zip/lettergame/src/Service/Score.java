/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Service;

import Service.LetterSuggest;
import lettergame.Constants;
import lettergame.PropertyHandler;

/**
 *
 * @author namdy
 */
public class Score {
    LetterSuggest LetterDetails = new LetterSuggest();
    Constants consData = new Constants();
    private static int countDownTime = Integer.parseInt(new PropertyHandler().getProperty("countDownTime"));
    
    public Integer point = 0,isFull;
    Boolean isvalidWord = true;
    
    public Integer IsAllLettersHave(String word,String [] List){       
        int idx=0;
        int tempcount = 0;
        String[] Wordary = word.split("");
        for(int i=0;i<Wordary.length;i++){            
            idx=0;
            while(idx < List.length){                
                if(Wordary[i].trim().equals(List[idx].trim()) ){                    
                    tempcount++;
                    break;
                } 
                idx++;
            }
        }           
        return tempcount;            
    }
    
    public Integer addBonus(int points,String word,String [] list){
        int idx=0;
        int tempcount = 0;
        String[] Wordary = word.split("");
        for(int i=0;i<Wordary.length;i++){           
            idx=0;
            while(idx < list.length){                
                if(Wordary[i].trim().equals(list[0].trim()) ){
                    points = points+5;
                }else if(Wordary[i].trim().equals(list[1].trim())){
                     points = points+5;                
                }else if(Wordary[i].trim().equals(list[2].trim())){
                     points = points+5;
                }                
                if(Wordary[i].trim().equals(list[0].trim()) && Wordary[i].trim().equals(list[1].trim()) && Wordary[i].trim().equals(list[2].trim())){
                    points = points+50;
                }
                idx++;
            }
        }
        
        return points;    
    }
    
    public Integer GetPoints(String word , int time , int playersCount , String [] letterlist , boolean isChanged){
        //isvalidWord = LetterDetails.isEnglishWord(word);        
        if(!isvalidWord || word =="" || word == null){
            point = 0;            
            return point;        
        }
        System.out.println(word.length()); 
        isFull = IsAllLettersHave(word,letterlist);
        if(word.length() == 11){                
                point = word.length()*playersCount;
                return point; 
                    
        }else{            
            point = isFull+((isFull*playersCount)-(11-isFull));
            System.out.println("points"+point);              
        }
        if(isChanged){
            point = point - 5;
        }        
        point = addBonus(point,word,letterlist); 
        if(time > countDownTime-10){
            point = point + 50;        
        }else if(time > countDownTime-20){
            point = point + 25;
        }else if(time > countDownTime-50){
            point = point + 15;
        }
        return point;    
    }
    
}
