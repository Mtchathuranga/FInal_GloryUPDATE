package lettergame;

import java.util.HashMap;
import javafx.scene.Node;

public class Constants {
	// All screens references
	public static final String Login_SCREEN = "Login";
	public static final String Login_SCREEN_FXML = "../Views/LogIn.fxml";
	public static final String MENU_SCREEN = "Menu";
	public static final String MENU_SCREEN_FXML = "../Views/Main_Menu.fxml";
	public static final String GAMEPLAY_SCREEN = "GameView";
	public static final String GAMEPLAY_SCREEN_FXML = "../Views/PlayGround.fxml"; 
	public static final String REGISTER_SCREEN = "Register";
	public static final String REGISTER_SCREEN_FXML = "../Views/Register.fxml";
        public static final String Board_SCREEN = "LBoard";
	public static final String Board_SCREEN_FXML = "../Views/LeaderBoard.fxml";
        public static final String Option_SCREEN = "Option";
	public static final String Option_SCREEN_FXML = "../Views/Option.fxml";
        public static final String OnlinePlayers_SCREEN = "OnlinePlayers";
	public static final String OnlinePlayers_SCREEN_FXML = "../Views/OnlinePlayers.fxml";
        public static final String NextRound_SCREEN = "NextRound";
	public static final String NextRound_FXML = "../Views/NextRound.fxml";
        public static final String OutPut_SCREEN = "FinalOutput";
	public static final String OutPut_SCREEN_FXML = "../Views/FinalOutput.fxml";
        public static final String HowToPlay_SCREEN = "HowToPlay";
	public static final String HowToPlay_SCREEN_FXML = "../Views/HowTOPlay.fxml";
        public static final String finalScores_SCREEN = "finalScores";
	public static final String finalScores_SCREEN_FXML = "../Views/scoresFinal.fxml";
        
	public static final String LETTER = "letter";
	public static final String VOWEL = "vowel";       
        
        // other values
	public static final String CONSONANT = "consonant";
        public static String OnlinePlayerName = "No User";
        public static Integer finalMarks = 0 ;//default value 0 
        public static String tempMarks = "" ;
        public static Integer tempROund = 0 ;
        
        public static  HashMap<String, String> InfoData = new HashMap<String, String>();
        
        public void addMap(String name, String value) {           
		InfoData.put(name, value);              
	}
}
