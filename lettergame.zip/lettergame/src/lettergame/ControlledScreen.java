package lettergame;

public interface ControlledScreen {
	public void setScreenParent(ScreensController screenPage);
}
